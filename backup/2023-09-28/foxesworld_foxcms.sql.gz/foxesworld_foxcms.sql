
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `foxesworld_foxcms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `foxesworld_foxcms`;
DROP TABLE IF EXISTS `antiBrute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antiBrute` (
  `id` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `recordTime` datetime(4) NOT NULL DEFAULT current_timestamp(4),
  `ip` varchar(16) DEFAULT NULL,
  `attempts` int(16) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `antiBrute` WRITE;
/*!40000 ALTER TABLE `antiBrute` DISABLE KEYS */;
/*!40000 ALTER TABLE `antiBrute` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `badgesList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badgesList` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `badgeName` varchar(64) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `img` varchar(64) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `badgesList` WRITE;
/*!40000 ALTER TABLE `badgesList` DISABLE KEYS */;
INSERT INTO `badgesList` VALUES
(1,'Support','FoxEngine Staff','/uploads/badges/staff.svg');
/*!40000 ALTER TABLE `badgesList` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groupAssociation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupAssociation` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(256) DEFAULT 'Noob',
  `groupNum` int(4) NOT NULL DEFAULT 4,
  `groupType` varchar(64) NOT NULL DEFAULT 'user',
  `badgeName` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groupAssociation` WRITE;
/*!40000 ALTER TABLE `groupAssociation` DISABLE KEYS */;
INSERT INTO `groupAssociation` VALUES
(1,'Admin',1,'admin',NULL),
(2,'Гостевичок',5,'guest',NULL),
(3,'Лис',4,'user',NULL);
/*!40000 ALTER TABLE `groupAssociation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `userBadges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userBadges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userLogin` varchar(64) NOT NULL,
  `badges` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `userBadges` WRITE;
/*!40000 ALTER TABLE `userBadges` DISABLE KEYS */;
INSERT INTO `userBadges` VALUES
(1,'AidenFox','[\"Support\"]');
/*!40000 ALTER TABLE `userBadges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(2) NOT NULL AUTO_INCREMENT,
  `login` varchar(16) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `user_group` int(4) NOT NULL DEFAULT 4,
  `realname` varchar(32) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `reg_date` varchar(32) NOT NULL,
  `last_date` varchar(32) NOT NULL,
  `profilePhoto` varchar(128) NOT NULL,
  `logged_ip` varchar(128) DEFAULT NULL,
  `userStatus` varchar(128) DEFAULT NULL,
  `land` varchar(64) DEFAULT NULL,
  `colorScheme` varchar(32) NOT NULL DEFAULT '#B5B8B1',
  `token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'AidenFox','$2y$10$SuxSHqM5ooEp/2mF.H.jTu5LFGOl2NC1NOPS4TnTIYBfgP6uWtQa2','lisssicin@yandex.ru',1,'Эйден','c8cd3182cc5ad36c932c35d49be41ffb','1676888597','1695839633','/uploads/users/AidenFox/profilePhoto.png','109.252.12.109','Founder','United Kingdom','#e72f00ad',''),
(2,'anonymous','','foxesworld.co.uk',5,'Анонимчик','','1676888597','76767','/uploads/users/anonymous/avatar.jpg',NULL,NULL,NULL,'#B5B8B1',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

