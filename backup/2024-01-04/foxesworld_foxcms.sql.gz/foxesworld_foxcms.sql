
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `foxesworld_foxcms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `foxesworld_foxcms`;
DROP TABLE IF EXISTS `antiBrute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antiBrute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) DEFAULT NULL,
  `recordTime` datetime(4) NOT NULL DEFAULT current_timestamp(4),
  `ip` varchar(16) DEFAULT NULL,
  `attempts` int(16) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `antiBrute` WRITE;
/*!40000 ALTER TABLE `antiBrute` DISABLE KEYS */;
/*!40000 ALTER TABLE `antiBrute` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `badgesList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badgesList` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `badgeName` varchar(64) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `img` varchar(64) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `badgesList` WRITE;
/*!40000 ALTER TABLE `badgesList` DISABLE KEYS */;
INSERT INTO `badgesList` VALUES
(1,'Staff','Команда FoxesCraft','/uploads/badges/staff.svg'),
(2,'BugHunter','Охотник за багами','/uploads/badges/bugHunter1.svg'),
(3,'Support','Поддержка FoxesCraft','/uploads/badges/support.svg'),
(4,'earlyUser','За раннюю регистрацию','/uploads/badges/earlyUser.svg'),
(5,'arasaka','Сила — в преемственности','/uploads/badges/arasaka.svg');
/*!40000 ALTER TABLE `badgesList` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groupAssociation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupAssociation` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(256) DEFAULT 'Noob',
  `groupNum` int(4) NOT NULL DEFAULT 4,
  `groupType` varchar(64) NOT NULL DEFAULT 'user',
  `badgeName` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groupAssociation` WRITE;
/*!40000 ALTER TABLE `groupAssociation` DISABLE KEYS */;
INSERT INTO `groupAssociation` VALUES
(1,'Admin',1,'admin',NULL),
(2,'Гостевичок',5,'guest',NULL),
(3,'Лис',4,'user',NULL);
/*!40000 ALTER TABLE `groupAssociation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groupPermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupPermissions` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(32) NOT NULL DEFAULT 'user',
  `permName` varchar(64) DEFAULT NULL,
  `permValue` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groupPermissions` WRITE;
/*!40000 ALTER TABLE `groupPermissions` DISABLE KEYS */;
INSERT INTO `groupPermissions` VALUES
(1,'admin','allowedColors','#e4005d9e,#3cc9489e,#e72f00ad,#2656caad'),
(2,'user','allowedColors','#e4005d9e,#3cc9489e,#2656caad,#26caad');
/*!40000 ALTER TABLE `groupPermissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `regCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regCodes` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `groupNum` int(2) NOT NULL DEFAULT 4,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `regCodes` WRITE;
/*!40000 ALTER TABLE `regCodes` DISABLE KEYS */;
INSERT INTO `regCodes` VALUES
(1,'test','test',6);
/*!40000 ALTER TABLE `regCodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `serverName` varchar(64) NOT NULL,
  `serverVersion` varchar(64) NOT NULL,
  `mainClass` varchar(64) NOT NULL,
  `forgeVersion` varchar(64) NOT NULL,
  `client` varchar(64) NOT NULL,
  `host` varchar(64) NOT NULL,
  `port` int(32) NOT NULL,
  `jreVersion` varchar(32) NOT NULL DEFAULT 'jre-8-271-x64',
  `mcpVersion` varchar(64) NOT NULL DEFAULT '20210115.111550',
  `forgeGroup` varchar(64) NOT NULL DEFAULT 'net.minecraftforge',
  `ignoreDirs` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES
(3,'Hi-Tech','1.12.2','net.minecraft.launchwrapper.Launch','','fmlclient','foxescraft.ru',25565,'jre-8u392-x64','20210115.111550','net.minecraftforge',NULL),
(8,'Space','1.12.2','net.minecraft.launchwrapper.Launch','','modified','foxescraft.ru',1337,'jre-8-381-x64','','','config,saves\r\n');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `userBadges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userBadges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userLogin` varchar(64) NOT NULL,
  `badges` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `userBadges` WRITE;
/*!40000 ALTER TABLE `userBadges` DISABLE KEYS */;
INSERT INTO `userBadges` VALUES
(0,'anonymous',''),
(1,'AidenFox','[{\"badgeName\":\"Support\",\"acquiredDate\":\"1676888597\"},{\"badgeName\":\"Staff\",\"acquiredDate\":\"1676888597\"},{\"badgeName\":\"BugHunter\",\"acquiredDate\":\"1696252523\"},{\"acquiredDate\":1699548631,\"badgeName\":\"earlyUser\"},{\"acquiredDate\":1699548631,\"badgeName\":\"arasaka\", \"description\": \"Saburo Arasaka\"}]'),
(4,'Haiky','[{\"badgeName\": \"earlyUser\", \"acquiredDate\": \"1699538096\"}]'),
(21,'miomoor','[{\"acquiredDate\":1702472298,\"badgeName\":\"earlyUser\"}]'),
(22,'Swift_Fox','[{\"acquiredDate\":1702474361,\"badgeName\":\"earlyUser\"}, {\"badgeName\":\"Support\",\"acquiredDate\":\"1702474361\"},{\"badgeName\":\"Staff\",\"acquiredDate\":\"1702474361\"}]'),
(26,'DallasFox',''),
(27,'Jesus','[{\"acquiredDate\":1702630650,\"badgeName\":\"earlyUser\"}]'),
(29,'RaKaLuS','[{\"acquiredDate\":1702630650,\"badgeName\":\"earlyUser\"}]'),
(30,'vbbbbbbbbbb',''),
(31,'Aenph1r','[{\"acquiredDate\":1703506143,\"badgeName\":\"earlyUser\"}]'),
(32,'Grace','[{\"acquiredDate\":1703521140,\"badgeName\":\"earlyUser\"}]'),
(33,'Wiibel','[{\"acquiredDate\":1703782983,\"badgeName\":\"earlyUser\"}]'),
(34,'Fixys','[{\"acquiredDate\":1703866056,\"badgeName\":\"earlyUser\"}]'),
(35,'Kapyssta','[{\"acquiredDate\":1703866527,\"badgeName\":\"earlyUser\"}]'),
(36,'Sensei','[{\"acquiredDate\":1703867364,\"badgeName\":\"earlyUser\"},{\"acquiredDate\":1703867364,\"badgeName\":\"arasaka\"}]'),
(37,'12Sensei12','[{\"acquiredDate\":1703868177,\"badgeName\":\"earlyUser\"},{\"acquiredDate\":1703868177,\"badgeName\":\"arasaka\"}]'),
(38,'dogiso','[{\"acquiredDate\":1703873376,\"badgeName\":\"earlyUser\"}]'),
(39,'MorelloFox',''),
(40,'lisssicin','[{\"acquiredDate\":1704285594,\"badgeName\":\"earlyUser\"}]');
/*!40000 ALTER TABLE `userBadges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(2) NOT NULL AUTO_INCREMENT,
  `login` varchar(16) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `user_group` int(4) NOT NULL DEFAULT 4,
  `realname` varchar(32) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `reg_date` varchar(32) NOT NULL,
  `last_date` varchar(32) NOT NULL,
  `profilePhoto` varchar(128) NOT NULL,
  `logged_ip` varchar(128) DEFAULT NULL,
  `userStatus` varchar(128) DEFAULT NULL,
  `land` varchar(64) DEFAULT NULL,
  `colorScheme` varchar(32) NOT NULL DEFAULT '#B5B8B1',
  `token` varchar(64) DEFAULT NULL,
  `reg_ip` varchar(64) DEFAULT NULL,
  `units` int(32) NOT NULL DEFAULT 0,
  `uuid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'AidenFox','$2y$10$SuxSHqM5ooEp/2mF.H.jTu5LFGOl2NC1NOPS4TnTIYBfgP6uWtQa2','lisssicin@yandex.ru',1,'Эйден','731fd59ec0c2284ed534ad3120558180','1676888597','1704274632','/uploads/users/AidenFox/profilePhoto.png','128.204.77.59','Founder','United Kingdom','#e72f00ad','c2477e78ec6dbabed284446061582df5',NULL,100,NULL),
(2,'anonymous','','foxesworld.co.uk',5,'Анонимчик','','1676888597','76767','/uploads/users/anonymous/avatar.jpg',NULL,NULL,NULL,'#B5B8B1',NULL,NULL,0,NULL),
(3,'MorelloFox','$2y$10$gZhbuMruQgFKgXnogXl9ieflz2iRmkz6lkAI1ZiwtNy7DCYSfPAei','lisssicin@ya.ru',4,'Хайки','e87d5652a88d2e78aa3460bf98802e64','1696252454','1696252523','/uploads/users/MorelloFox/profilePhoto.jpg','31.173.85.243','Главный Фармер','Твоя мамаша','#B5B8B1',NULL,'31.173.85.243',0,NULL),
(5,'vbbbbbbbbbb','$2y$10$jszDZAwzlII6tW5Lg7txkOIaiev78rZz9OxD1U9VBpa8x4wBGGkiy','89031122149@yandex.ru',4,'Эйден','c359a8c368dfecd9509acf2eefb50437','1697037792','1699047840','/templates/foxengine/assets/img/no-photo.jpg','109.252.12.109',NULL,NULL,'#B5B8B1',NULL,'109.252.12.109',0,NULL),
(11,'Haiky','$2y$10$ZIbUbNtZn9GRpr8btajUj.nLASC7Q9DBgtsNJvSBniFWJrpsb9QWm','haiky@mail.ru',4,'Хоупс','1eab5237ece784608120fbb2f80ed340','1699047906','1699047976','/templates/foxengine/assets/img/no-photo.jpg','178.162.44.5',NULL,NULL,'#B5B8B1',NULL,'178.162.44.5',0,NULL),
(12,'Jesus','$2y$10$ryvEmg3UGdx7oshqGsARw.6xwDdvRSDWENaryFiLM9YzntatZI9Zm','liuss@ya.ru',4,'Хайки','35ba525f4bdac9e13d59ac3dd7733e5a','1699263101','1704285721','/templates/foxengine/assets/img/no-photo.jpg','178.176.75.146','Jesus','Россия','#3cc9489e','','109.252.12.109',0,'e9829608dd90ff6b8bf7cb50746eae78'),
(17,'DallasFox','$2y$10$swgnNiDWbRAqWfhG/sbwHudfUG/3W25lA8TZ0p87scFzisi7OYYxm','sklyurov98@mail.ru',4,'Даллас','a6c370a2a6046a4f72f208add3c0d375','1699558853','1699558922','/uploads/users/DallasFox/profilePhoto.png','45.91.163.11','Начальник Геодезической службы','Россия','#B5B8B1',NULL,'45.91.163.11',0,NULL),
(21,'miomoor','$2y$10$nER5gFOGQYfq3hYDUKOmB.tLwUz2qPfKGCn9TRIG/GpHA2IuFmNmS','tt@gg.rr',4,'Агро','19d2f27478f0e8245b503928006daee2','1702469352','1702472364','/templates/foxengine/assets/img/no-photo.jpg','109.252.3.17',NULL,NULL,'#B5B8B1',NULL,'109.252.3.17',0,NULL),
(22,'Swift_Fox','$2y$10$VQAMC9Z4G2mt3ptmTFviOurInm1hxkQi6lzOf8rhfk5Q/MyRaGr3m','gneffer2001@gmail.com',1,'Гоблин','9efd3c9e84d6b80743a25c4684c9ec61','1702474360','1704243008','/uploads/users/Swift_Fox/profilePhoto.jpg','49.143.123.207','Первый','South Korea','#3cc9489e','312ae71786de2eb2d747fb2fe39549c5','49.143.123.207',0,'545787180b6f3fdcabe6fb349f8adaa4'),
(23,'RaKaLuS','$2y$10$.Hulj62.ahjVMjlE6W6uoOxagnblB9NrB6FwRonJcIWzEyEDj8eze','sir.d-i-a2014@mail.ru',4,'Хач трюкач','2312983da63ef13d94d3f5e6717f303d','1702630649','1704346313','/templates/foxengine/assets/img/no-photo.jpg','90.188.77.246',NULL,NULL,'#B5B8B1','','90.188.77.246',0,'412cbd342e8a3f2a959433d35e3da858'),
(24,'Aenph1r','$2y$10$jPuI1djwncR3frU/KNdJl.71H99cigErWuEu8YWBgYy8h9GlNEm16','konstantinthecool@gmail.com',4,'Дурилка','f9e583f47060581a11ef63678f8b5cf3','1703506143','1703508664','/templates/foxengine/assets/img/no-photo.jpg','94.51.66.237',NULL,NULL,'#B5B8B1','','94.51.66.237',0,'7abbd2cba14c3d8eb6aacfce62b1e335'),
(25,'Grace','$2y$10$lXOXXSKgDIWvLmau2gYZV.QiGL3GnxswBxPm8k4sd9.TMypkfRzJm','johnjonathangrace@gmail.com',4,'Rasta','e15593d46869d743537e3c1b8e69dad1','1703521140','1703523234','/templates/foxengine/assets/img/no-photo.jpg','185.130.83.149','Yes','Ад','#2656caad','cd7fc62a050b6beb7787ed33e6090cbf','185.130.83.149',0,'68727d15820a3c2ebc29636a8ba6d666'),
(26,'Wiibel','$2y$10$05GuVa88gtSGhCW1F6nCLeR80hSXQn3.5QTECVL/cDH9JfqnF53DO','fazzussdisc@gmail.com',4,'Дурилка','d8104306737460db7feb80bde61ed894','1703782982','1703956063','/templates/foxengine/assets/img/no-photo.jpg','82.215.122.106',NULL,NULL,'#B5B8B1','','82.215.122.106',0,'3668b37aa43462d8a2c549a776aae077'),
(27,'Fixys','$2y$10$9feFZRiG5X9E4cX.IJjRdua6lFzf54IO5JH63JACRWCPMVqKS2Cha','kakaskryto@mail.ru',4,'Хайки','7170f8dbcf6daa5183148c08efb08bf2','1703866056','1703866730','/templates/foxengine/assets/img/no-photo.jpg','37.212.198.100',NULL,NULL,'#B5B8B1',NULL,'37.212.198.100',0,NULL),
(28,'Kapyssta','$2y$10$2nf6MLaS1sNP0UYn.NWH2uPuDnJCZB/YnAEKJEhmpsRv2loKr6KaO','kapysta285@gmail.com',4,'Бычок','732f5385ade21889598335912dd19bb9','1703866527','1703866615','/templates/foxengine/assets/img/no-photo.jpg','188.32.144.22',NULL,NULL,'#B5B8B1',NULL,'188.32.144.22',0,NULL),
(29,'Sensei','$2y$10$MRAj7lo1RuYGRYRrbAzMMeRKS2RdUsgKFztVPJ7qDxuT6TV7ixroe','Time9335@vk.com',4,'Дурилка','6cbec98134f0e7d2bd3e19b1dd2f2998','1703867363','1703868108','/templates/foxengine/assets/img/no-photo.jpg','91.243.110.87',NULL,NULL,'#B5B8B1','180479cf4046aab2d2d21e8d8a20fd46','91.243.110.87',0,'e558734d5a4fb68a183e67c9b07a983b'),
(30,'12Sensei12','$2y$10$ThkowDBHHanByqP4Uh91kO4iDyEEN4ywscAn7DcTFlBS4LgkJ7nya','Time133377@mail.ru',4,'Прыгунок','12d4ba9aaac41a72e580eb3fcb570cce','1703868177','1704097713','/templates/foxengine/assets/img/no-photo.jpg','91.243.110.87',NULL,NULL,'#B5B8B1','','91.243.110.87',0,'dc12967efe1af7e817f62da01e6acbf0'),
(31,'dogiso','$2y$10$YP2dc3aX83m8Zs19ZNnAZeE0zSiuhr/iUPWlB82vl8O6wz0bs9QWO','danila.sabunin212@mail.ru',4,'Гусь гибридный','168e5859672ade00df54c7c64242264b','1703873375','1703873443','/templates/foxengine/assets/img/no-photo.jpg','77.222.112.242',NULL,NULL,'#B5B8B1',NULL,'77.222.112.242',0,NULL),
(32,'lisssicin','$2y$10$xelETh6f2FWgsm7UyOCOeutGj/V/qu/KYaNwnBRsGCGBP5vuR61de','test15@inbox.ru',4,'Иван','2d3d5c884292a53305dfe9318d42750d','1704285594','1704358470','/templates/foxengine/assets/img/no-photo.jpg','31.173.86.60','lisssicin','Moscow','#26caad','0c2223e579478dc17c885ed0339b749f','178.176.75.146',0,'d76857af9bdb0d9641c63ab17a662c58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `usersession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usersession` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `user` varchar(128) DEFAULT NULL,
  `accessToken` varchar(512) DEFAULT NULL,
  `serverId` varchar(256) DEFAULT NULL,
  `userMd5` varchar(256) DEFAULT NULL,
  `passMd5` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `usersession` WRITE;
/*!40000 ALTER TABLE `usersession` DISABLE KEYS */;
INSERT INTO `usersession` VALUES
(3,'RaKaLuS','2312983da63ef13d94d3f5e6717f303d','-6c2a836191f4685a38596a8d69b033c4ced4266b','412cbd342e8a3f2a959433d35e3da858','9836b48dae5ac4a1e375b932c613004d'),
(4,'Swift_Fox','07c0f47c6853ea2fbffbbaf33c825f05',NULL,'545787180b6f3fdcabe6fb349f8adaa4','5d9acc79dac04e7f953bf2f03848746b'),
(5,'Aenph1r','f9e583f47060581a11ef63678f8b5cf3','82320655188cba38f852c11f3df3c2a2c25acd6','7abbd2cba14c3d8eb6aacfce62b1e335','2c9576c430caea1e324bcb05428aadc4'),
(6,'Grace','e15593d46869d743537e3c1b8e69dad1','6a76ff46dfe173bf56593cbb6f60d223247c0aa8','68727d15820a3c2ebc29636a8ba6d666','d30789fe619eb2d816a4cff249d086b5'),
(9,'Jesus','35ba525f4bdac9e13d59ac3dd7733e5a','-76d2ed0230fd56ac15b072fc1356ef8150655fb1','e9829608dd90ff6b8bf7cb50746eae78','5838691dbcc7e5da137cb267de8586cc'),
(10,'Wiibel','d8104306737460db7feb80bde61ed894',NULL,'3668b37aa43462d8a2c549a776aae077','8f0dce357af74b0098cfae16080ae8af'),
(11,'Sensei','6cbec98134f0e7d2bd3e19b1dd2f2998',NULL,'e558734d5a4fb68a183e67c9b07a983b','1bbc6e368891cb8721bbd38558e95418'),
(12,'12Sensei12','12d4ba9aaac41a72e580eb3fcb570cce','-61a5e6b604f811e661d80a970f84f2b7de7154a5','dc12967efe1af7e817f62da01e6acbf0','9e00d600dfa8daf8c4c006260f4b78b3'),
(13,'AidenFox','731fd59ec0c2284ed534ad3120558180',NULL,'436246fdf1d0f84b5b2ca7e0646aecc9','c929eceb3487ee60d283c6fbed44442e'),
(14,'lisssicin','2d3d5c884292a53305dfe9318d42750d','-164cec111379b94271b86c2472a684a4579d8942','d76857af9bdb0d9641c63ab17a662c58','6ec62f750668ccce7d77a6693ce0d3b9');
/*!40000 ALTER TABLE `usersession` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

