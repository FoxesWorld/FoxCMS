
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `foxesworld_foxcms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `foxesworld_foxcms`;
DROP TABLE IF EXISTS `antiBrute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antiBrute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) DEFAULT NULL,
  `recordTime` datetime(4) NOT NULL DEFAULT current_timestamp(4),
  `ip` varchar(16) DEFAULT NULL,
  `attempts` int(16) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `antiBrute` WRITE;
/*!40000 ALTER TABLE `antiBrute` DISABLE KEYS */;
/*!40000 ALTER TABLE `antiBrute` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `badgesList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badgesList` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `badgeName` varchar(64) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `img` varchar(64) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `badgesList` WRITE;
/*!40000 ALTER TABLE `badgesList` DISABLE KEYS */;
INSERT INTO `badgesList` VALUES
(1,'Staff','FoxEngine Staff','/uploads/badges/staff.svg'),
(2,'BugHunter','Bug Hunter','/uploads/badges/bugHunter1.svg'),
(3,'Support','Support','/uploads/badges/support.svg');
/*!40000 ALTER TABLE `badgesList` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groupAssociation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupAssociation` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(256) DEFAULT 'Noob',
  `groupNum` int(4) NOT NULL DEFAULT 4,
  `groupType` varchar(64) NOT NULL DEFAULT 'user',
  `badgeName` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groupAssociation` WRITE;
/*!40000 ALTER TABLE `groupAssociation` DISABLE KEYS */;
INSERT INTO `groupAssociation` VALUES
(1,'Admin',1,'admin',NULL),
(2,'Гостевичок',5,'guest',NULL),
(3,'Лис',4,'user',NULL);
/*!40000 ALTER TABLE `groupAssociation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groupPermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupPermissions` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(32) NOT NULL DEFAULT 'user',
  `permName` varchar(64) DEFAULT NULL,
  `permValue` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groupPermissions` WRITE;
/*!40000 ALTER TABLE `groupPermissions` DISABLE KEYS */;
INSERT INTO `groupPermissions` VALUES
(1,'admin','allowedColors','#e4005d9e,#3cc9489e,#e72f00ad,#2656caad'),
(2,'user','allowedColors','#e4005d9e,#3cc9489e,#2656caad,#26caad');
/*!40000 ALTER TABLE `groupPermissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `regCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regCodes` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `groupNum` int(2) NOT NULL DEFAULT 4,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `regCodes` WRITE;
/*!40000 ALTER TABLE `regCodes` DISABLE KEYS */;
INSERT INTO `regCodes` VALUES
(1,'test','test',6);
/*!40000 ALTER TABLE `regCodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `serverName` varchar(64) NOT NULL,
  `serverVersion` varchar(64) NOT NULL,
  `mainClass` varchar(64) NOT NULL,
  `forgeVersion` varchar(64) NOT NULL,
  `client` varchar(64) NOT NULL,
  `host` varchar(64) NOT NULL,
  `port` int(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES
(2,'Foxesworld','1.16.4','net.minecraft.client.main.Main','','fmlclient','localhost',25565),
(3,'Hi-Tech','1.12.2','','','','',25565),
(4,'HardTech','1.12.2','','','','',25565);
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `userBadges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userBadges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userLogin` varchar(64) NOT NULL,
  `badges` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `userBadges` WRITE;
/*!40000 ALTER TABLE `userBadges` DISABLE KEYS */;
INSERT INTO `userBadges` VALUES
(1,'AidenFox','[{\"badgeName\": \"Support\", \"acquiredDate\": \"1676888597\"},{\"badgeName\": \"Staff\", \"acquiredDate\": \"1676888597\"}, {\"badgeName\": \"BugHunter\", \"acquiredDate\": \"1696252523\"}]');
/*!40000 ALTER TABLE `userBadges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(2) NOT NULL AUTO_INCREMENT,
  `login` varchar(16) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `user_group` int(4) NOT NULL DEFAULT 4,
  `realname` varchar(32) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `reg_date` varchar(32) NOT NULL,
  `last_date` varchar(32) NOT NULL,
  `profilePhoto` varchar(128) NOT NULL,
  `logged_ip` varchar(128) DEFAULT NULL,
  `userStatus` varchar(128) DEFAULT NULL,
  `land` varchar(64) DEFAULT NULL,
  `colorScheme` varchar(32) NOT NULL DEFAULT '#B5B8B1',
  `token` varchar(64) DEFAULT NULL,
  `reg_ip` varchar(64) DEFAULT NULL,
  `units` int(32) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'AidenFox','$2y$10$SuxSHqM5ooEp/2mF.H.jTu5LFGOl2NC1NOPS4TnTIYBfgP6uWtQa2','lisssicin@yandex.ru',1,'Эйден','cecb86c47ab8899d29e4f87cf97bc1b4','1676888597','1698761586','/uploads/users/AidenFox/profilePhoto.png','31.173.83.21','Founder','United Kingdom','#e72f00ad','8ba930b0a38e81fd2e53e49e02a1a374',NULL,100),
(2,'anonymous','','foxesworld.co.uk',5,'Анонимчик','','1676888597','76767','/uploads/users/anonymous/avatar.jpg',NULL,NULL,NULL,'#B5B8B1',NULL,NULL,0),
(3,'MorelloFox','$2y$10$gZhbuMruQgFKgXnogXl9ieflz2iRmkz6lkAI1ZiwtNy7DCYSfPAei','lisssicin@ya.ru',4,'Хайки','e87d5652a88d2e78aa3460bf98802e64','1696252454','1696252523','/uploads/users/MorelloFox/profilePhoto.png','31.173.85.243','Главный Фармер','Твоя мамаша','#B5B8B1',NULL,'31.173.85.243',0),
(5,'alcor','$2y$10$jszDZAwzlII6tW5Lg7txkOIaiev78rZz9OxD1U9VBpa8x4wBGGkiy','89031122149@yandex.ru',4,'Эйден','c359a8c368dfecd9509acf2eefb50437','1697037792','1697038145','/templates/foxengine/assets/img/no-photo.jpg','109.252.12.109',NULL,NULL,'#B5B8B1',NULL,'109.252.12.109',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

